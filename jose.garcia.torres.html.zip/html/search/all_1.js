var searchData=
[
  ['borraralfabeto_0',['borrarAlfabeto',['../class_cjt___alfabeto.html#ab7c82a73a7e1751076d166e78d49e221',1,'Cjt_Alfabeto']]],
  ['borrarmensaje_1',['borrarMensaje',['../class_cjt___mensaje.html#a3463abcb815763cc7d07c9b87cdb2928',1,'Cjt_Mensaje']]]
];
