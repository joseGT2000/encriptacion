var searchData=
[
  ['listaralfabeto_0',['listarAlfabeto',['../class_cjt___alfabeto.html#aef52ba625d364ad5c9ede7a2e1b7f04f',1,'Cjt_Alfabeto']]],
  ['listarmensajes_1',['listarMensajes',['../class_cjt___mensaje.html#acf1630e397c188ad5ccb4ada27d9d9e3',1,'Cjt_Mensaje']]]
];
