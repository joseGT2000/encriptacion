var searchData=
[
  ['la_20criptografía_20es_20la_20ciencia_20que_20trata_20sobre_20encriptar_20y_20desencriptar_20información_2e_0',['La Criptografía es la ciencia que trata sobre encriptar y desencriptar información.',['../index.html',1,'']]]
];
