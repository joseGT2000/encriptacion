var searchData=
[
  ['addalfabeto_0',['addAlfabeto',['../class_cjt___alfabeto.html#a0fdb987997271307827f7136c02d9eaa',1,'Cjt_Alfabeto']]],
  ['addmensaje_1',['addMensaje',['../class_cjt___mensaje.html#ac59f018bdc16eedaac5e8d93bb1c4083',1,'Cjt_Mensaje']]],
  ['alfabeto_2',['Alfabeto',['../class_alfabeto.html#a218c7371b04d202f3c7bfbc2640f091a',1,'Alfabeto']]]
];
